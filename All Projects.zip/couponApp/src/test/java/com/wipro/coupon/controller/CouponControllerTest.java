package com.wipro.coupon.controller;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.coupon.dto.request.Coupon;
import com.wipro.coupon.exception.CouponIdNotFoundException;
import com.wipro.coupon.service.CouponService;

@WebMvcTest(CouponController.class)
public class CouponControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

   // @MockBean
    private CouponService couponService;

    private Coupon createCoupon(
            Integer id,
            String couponName,
            Double discount
            ) {

        Coupon coupon = new Coupon();

        coupon.setId(id);
        coupon.setCouponName(couponName);
        coupon.setDiscount(discount);
        
        return coupon;
    }

    @Test
    void testSaveCoupon() throws Exception {

        Coupon coupon = createCoupon(
                1,
                "AAA",
                53.0
                
        );

        when(couponService.saveCoupon(any(Coupon.class)))
                .thenReturn(coupon);

        mockMvc.perform(post("/api/v1/coupons")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(coupon)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.couponName")
                        .value("AAA"))
                .andExpect(jsonPath("$.discount")
                        .value(53.0))
                ;

        verify(couponService)
                .saveCoupon(any(Coupon.class));
    }

    @Test
    void testFindCouponById() throws Exception {

        Coupon coupon = createCoupon(
                1,
                "AAA",
                53.0
             
        );

        when(couponService.findById(1))
                .thenReturn(coupon);

        mockMvc.perform(get("/api/v1/coupons/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.couponName")
                        .value("AAA"))
                .andExpect(jsonPath("$.discount")
                        .value(53.0))
                ;

        verify(couponService).findById(1);
    }

    @Test
    void testFindCouponByIdNotFound() throws Exception {

        when(couponService.findById(99))
                .thenThrow(new CouponIdNotFoundException(99));

        mockMvc.perform(get("/api/v1/coupons/99"))
                .andExpect(status().isNotFound());

        verify(couponService).findById(99);
    }

    @Test
    void testFindAllcoupons() throws Exception {

    	Coupon couponOne = createCoupon(
                1,
                "AAA",
                53.0
        );

    	Coupon couponTwo = createCoupon(
                2,
                "BBB",
                83.0
        );


        List<Coupon> coupons = Arrays.asList(
                couponOne,
                couponTwo
        );

        when(couponService.findAll())
                .thenReturn(coupons);

        mockMvc.perform(get("/api/v1/coupons"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].couponName")
                        .value("AAA"))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].couponName")
                        .value("BBB"));

        verify(couponService).findAll();
    }

    @Test
    void testFindCouponByCouponName() throws Exception {

        Coupon coupon = createCoupon(
                1,
                "AAA",
                53.0
        );

        when(couponService.findByCouponName("AAA"))
                .thenReturn(coupon);

        mockMvc.perform(
                get("/api/v1/coupons/couponName/AAA"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.couponName")
                        .value("AAA"))
                .andExpect(jsonPath("$.discount")
                        .value(53.0));

        verify(couponService)
                .findByCouponName("AAA");
    }

   /* @Test
    void testFindEmployeeByFirstNameNotFound()
            throws Exception {

        when(employeeService.findByFirstName("Unknown"))
                .thenThrow(new EmployeeIdNotFoundException("Employee not found with first name: Unknown"));

        mockMvc.perform(
                get("/api/v1/employees/firstName/Unknown"))
                .andExpect(status().isNotFound());

        verify(employeeService)
                .findByFirstName("Unknown");
    }*/
}