package com.wipro.coupon.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.coupon.dto.request.Coupon;
import com.wipro.coupon.exception.CouponIdNotFoundException;
import com.wipro.coupon.service.CouponService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Value;

@RestController
@RequestMapping("/api/v1/coupons")
@Tag(
        name = "Coupon APIs",
        description = "APIs for managing coupon records"
)
public class CouponController {
	 private CouponService couponService;
	 @Value("${server.port}")
	    private String port;
	 public CouponController(@Autowired CouponService couponService) {
		 super();
		 this.couponService=couponService;
 }
	 @Operation(
		        summary = "Save coupon",
		        description = "Creates a new coupon"
		)
		@ApiResponses(value = {
		        @ApiResponse(
		                responseCode = "201",
		                description = "Coupon created successfully"
		        ),
		        @ApiResponse(
		                responseCode = "400",
		                description = "Invalid coupon data"
		        )
		})	 
 @PostMapping
 public ResponseEntity<Coupon> saveCoupon(@RequestBody Coupon coupon) {
	return new ResponseEntity<Coupon>(couponService.saveCoupon(coupon),HttpStatus.CREATED);
 }
	 @Operation(
		        summary = "Find coupon by ID",
		        description = "Returns an coupon using the coupon ID"
		)
		@ApiResponses(value = {
		        @ApiResponse(
		                responseCode = "200",
		                description = "Coupon found"
		        ),
		        @ApiResponse(
		                responseCode = "404",
		                description = "Coupon ID not found"
		        )
		})	 
 @GetMapping("/{id}")
 public ResponseEntity<Coupon> getCouponById(@PathVariable int id) throws CouponIdNotFoundException{
	 return new ResponseEntity<Coupon>(couponService.findById(id),HttpStatus.OK);
 }
	
 @GetMapping
 public ResponseEntity<List<Coupon>> getAllCoupon(){
	 System.out.println("In Ger all");
	 return new ResponseEntity<List<Coupon>>(couponService.findAll(),HttpStatus.OK);
 }	
 @Operation(
	        summary = "Find coupon by first name",
	        description = "Returns an coupon using the first name"
	)
	@ApiResponses(value = {
	        @ApiResponse(
	                responseCode = "200",
	                description = "Coupon found"
	        ),
	        @ApiResponse(
	                responseCode = "404",
	                description = "Coupon name not found"
	        )
	})	
 @GetMapping("/couponName/{couponName}")
 public ResponseEntity<Coupon> getCouponByCouponName(@PathVariable String couponName) {
     System.out.println("Request handled by COUPONAPP running on port: " + port);
     return new ResponseEntity<Coupon>(couponService.findByCouponName(couponName), HttpStatus.OK);
 }	
	 
 }
