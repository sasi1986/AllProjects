package com.wipro.coupon.config;

import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.Contact;
@Configuration
@OpenAPIDefinition(
		info=@Info( title="Employee Management REST API", 
		version="1.0",
		description="API documentation for managing employeerecords",
		contact=@Contact(name="Wipro Employee Team")
		)
		)
public class OpenApiConfig {

}