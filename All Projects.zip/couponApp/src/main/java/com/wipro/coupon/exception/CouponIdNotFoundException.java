package com.wipro.coupon.exception;

public class CouponIdNotFoundException extends Exception {
	private Integer id;
	public CouponIdNotFoundException(Integer id)
	{
		this.id=id;
		
	}
	@Override
	public String toString()
	{
		System.out.println("hello");
		return "Coupon ID "+id+" is not found";
	}
	
	 public CouponIdNotFoundException(String message) {
	        super(message);
	        //this.id = 0;
	 }
}
