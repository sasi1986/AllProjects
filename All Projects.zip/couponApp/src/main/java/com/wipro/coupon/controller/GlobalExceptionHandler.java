package com.wipro.coupon.controller;

import java.net.http.HttpResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.wipro.coupon.dto.response.ErrorResponse;
import com.wipro.coupon.exception.CouponIdNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(CouponIdNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleCouponIdNotException(CouponIdNotFoundException ex)
	{
		ErrorResponse errorResponse=new ErrorResponse();
		errorResponse.setMessage(ex.toString());
		errorResponse.setStatus(HttpStatus.NOT_FOUND);
		System.out.println("error");
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.NOT_FOUND);
	}
	
    

}
