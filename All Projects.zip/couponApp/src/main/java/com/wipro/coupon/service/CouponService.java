package com.wipro.coupon.service;

import java.util.List;

import com.wipro.coupon.dto.request.Coupon;
import com.wipro.coupon.exception.CouponIdNotFoundException;

public interface CouponService {
	Coupon saveCoupon(Coupon coupon);
	Coupon findById(int id) throws CouponIdNotFoundException;
	List<Coupon> findAll();
	Coupon findByCouponName(String couponName);
	
 
 
}
