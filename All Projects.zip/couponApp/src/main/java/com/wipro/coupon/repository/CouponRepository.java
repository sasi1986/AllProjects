package com.wipro.coupon.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.coupon.dto.request.Coupon;
@Repository
public interface CouponRepository extends JpaRepository <Coupon,Integer>{
	Coupon findByCouponName(String couponName);

}
 
