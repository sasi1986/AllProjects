package com.wipro.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootTest
class EurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
