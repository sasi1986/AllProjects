package com.wipro.controller;

import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.wipro.dto.request.Product;
import com.wipro.exception.ProductIdNotFoundException;
import com.wipro.service.ProductService;

import tools.jackson.databind.ObjectMapper;

@WebMvcTest(ProductController.class)
@ContextConfiguration(classes = {ProductController.class, GlobalExceptionHandler.class})
public class ProductControllerTest {

    @MockitoBean
    private ProductService productService;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testSaveProduct() throws Exception {
        // arrange
        Product product = new Product();
        product.setPid(1);
        product.setProductName("Laptop");
        product.setQuantity(10);
        product.setPrice(55000.0);
        product.setDescription("Dell Inspiron 15");

        when(productService.saveProduct(any(Product.class))).thenReturn(product);

        // act & assert
        mockMvc.perform(post("/api/v1/products")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(product)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.pid").value(1))
                .andExpect(jsonPath("$.productName").value("Laptop"))
                .andExpect(jsonPath("$.quantity").value(10))
                .andExpect(jsonPath("$.price").value(55000.0));
    }

    @Test
    void testGetProductById() throws Exception {
        // arrange
        Product product = new Product();
        product.setPid(1);
        product.setProductName("Laptop");
        product.setQuantity(10);
        product.setPrice(55000.0);
        product.setDescription("Dell Inspiron 15");

        when(productService.findById(1)).thenReturn(product);

        // act & assert
        mockMvc.perform(get("/api/v1/products/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pid").value(1))
                .andExpect(jsonPath("$.productName").value("Laptop"));
    }

    @Test
    void testGetProductById_NotFound() throws Exception {
        // arrange
        when(productService.findById(99)).thenThrow(new ProductIdNotFoundException(99));

        // act & assert
        mockMvc.perform(get("/api/v1/products/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Product ID 99 is not found"));

        verify(productService).findById(99);
    }

    @Test
    void testGetAllProducts() throws Exception {
        // arrange
        Product p1 = new Product();
        p1.setPid(1);
        p1.setProductName("Laptop");
        p1.setQuantity(10);
        p1.setPrice(55000.0);

        Product p2 = new Product();
        p2.setPid(2);
        p2.setProductName("Mouse");
        p2.setQuantity(50);
        p2.setPrice(500.0);

        List<Product> products = Arrays.asList(p1, p2);
        when(productService.findAll()).thenReturn(products);

        // act & assert
        // act & assert
        mockMvc.perform(get("/api/v1/products")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].productName").value("Laptop"))
                .andExpect(jsonPath("$[1].productName").value("Mouse"));
    }


    @Test
    void testFindByProductName() throws Exception {
        // arrange
        Product product = new Product();
        product.setPid(1);
        product.setProductName("Laptop");
        product.setQuantity(10);
        product.setPrice(55000.0);

        when(productService.findByProductName("Laptop")).thenReturn(Arrays.asList(product));

        // act & assert
        mockMvc.perform(get("/api/v1/products/productName/Laptop")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].productName").value("Laptop"));
    }

    @Test
    void testUpdateProduct() throws Exception {
        // arrange
        Product updated = new Product();
        updated.setPid(1);
        updated.setProductName("Gaming Laptop");
        updated.setQuantity(8);
        updated.setPrice(75000.0);
        updated.setDescription("Updated specs");

        when(productService.updateProduct(eq(1), any(Product.class))).thenReturn(updated);

        // act & assert
        mockMvc.perform(put("/api/v1/products/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updated)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.productName").value("Gaming Laptop"))
                .andExpect(jsonPath("$.price").value(75000.0));

        verify(productService).updateProduct(eq(1), any(Product.class));
    }

    @Test
    void testDeleteProduct() throws Exception {
        // arrange
        doNothing().when(productService).deleteProduct(1);

        // act & assert
        mockMvc.perform(delete("/api/v1/products/1"))
                .andExpect(status().isNoContent());

        verify(productService).deleteProduct(1);
    }
}
