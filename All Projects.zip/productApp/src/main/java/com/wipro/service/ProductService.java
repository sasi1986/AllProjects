package com.wipro.service;

import java.util.List;

import com.wipro.dto.request.Product;
import com.wipro.exception.ProductIdNotFoundException;

public interface ProductService {
	Product saveProduct(Product product);
    Product findById(int pid) throws ProductIdNotFoundException;
    List<Product> findAll();
    List<Product> findByProductName(String productName);
    Product updateProduct(int pid, Product product) throws ProductIdNotFoundException;
    void deleteProduct(int pid) throws ProductIdNotFoundException;

}
