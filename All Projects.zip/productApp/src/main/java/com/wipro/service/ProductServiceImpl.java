package com.wipro.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.client.CouponClient;
import com.wipro.dto.request.*;
import com.wipro.dto.response.CouponResponse;
import com.wipro.exception.ProductIdNotFoundException;
import com.wipro.repository.ProductRepository;

import jakarta.transaction.Transactional;

@Service
public class ProductServiceImpl implements ProductService {

    private ProductRepository productRepository;
    private CouponClient couponClient;

   // @Autowired
    public ProductServiceImpl(ProductRepository productRepository, CouponClient couponClient) {
        super();
        this.productRepository = productRepository;
        this.couponClient = couponClient;
    }

    @Transactional
    @Override
    public Product saveProduct(Product product) {
        if (product.getCouponCode() != null && !product.getCouponCode().isEmpty()) {
            CouponResponse coupon = couponClient.getCouponByName(product.getCouponCode());
            if (coupon != null) {
                double discountAmount = (product.getPrice() * coupon.getDiscount()) / 100.0;
                product.setPrice(product.getPrice() - discountAmount);
            }
        }
        return productRepository.save(product);
    }

    @Override
    public Product findById(int pid) throws ProductIdNotFoundException {
        Optional<Product> optionalContainer = productRepository.findById(pid);
        if (optionalContainer.isPresent())
            return optionalContainer.get();
        else
            throw new ProductIdNotFoundException(pid);
    }

    @Override
    public List<Product> findAll() {
        return productRepository.findAll();
    }

    @Override
    public List<Product> findByProductName(String productName) {
        return productRepository.findByProductName(productName);
    }

    @Transactional
    @Override
    public Product updateProduct(int pid, Product updatedProduct) throws ProductIdNotFoundException {
        Product existing = findById(pid);
        existing.setProductName(updatedProduct.getProductName());
        existing.setQuantity(updatedProduct.getQuantity());
        existing.setPrice(updatedProduct.getPrice());
        existing.setDescription(updatedProduct.getDescription());
        return productRepository.save(existing);
    }

    @Transactional
    @Override
    public void deleteProduct(int pid) throws ProductIdNotFoundException {
        Product existing = findById(pid);
        productRepository.delete(existing);
    }
}
