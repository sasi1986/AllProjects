package com.wipro.exception;

@SuppressWarnings("serial")
public class ProductIdNotFoundException extends Exception{
	private int pid;

    public ProductIdNotFoundException(int pid) {
        this.pid = pid;
    }

    @Override
    public String toString() {
        return "Product ID " + pid + " is not found";
    }

}
