package com.wipro.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.wipro.dto.response.CouponResponse;

@FeignClient(name = "COUPONAPP")
public interface CouponClient {
	@GetMapping("/api/v1/coupons/couponName/{couponName}")
    CouponResponse getCouponByName(@PathVariable("couponName") String couponName);

}
