package com.wipro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.dto.request.Product;
import java.util.*;

@Repository
public interface ProductRepository  extends JpaRepository<Product, Integer>{
	List<Product> findByProductName(String productName);
}
