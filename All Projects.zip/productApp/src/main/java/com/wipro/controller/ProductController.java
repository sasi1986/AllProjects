package com.wipro.controller;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.wipro.dto.request.*;
import com.wipro.service.*;
import com.wipro.exception.*;
import io.swagger.v3.oas.annotations.*;
import java.util.*;

@RequestMapping("api/v1/products")
@RestController
public class ProductController {

	private ProductService productService;

    public ProductController(@Autowired ProductService productService) {
        super();
        this.productService = productService;
    }

    @Operation(summary = "Create a new product")
    @PostMapping
    public ResponseEntity<Product> saveProduct(@RequestBody Product product) {
        return new ResponseEntity<Product>(productService.saveProduct(product), HttpStatus.CREATED);
    }

    @Operation(summary = "Get product by ID")
    @GetMapping("/{pid}")
    public ResponseEntity<Product> getProductById(@PathVariable int pid) throws ProductIdNotFoundException {
        return new ResponseEntity<Product>(productService.findById(pid), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        return new ResponseEntity<List<Product>>(productService.findAll(), HttpStatus.OK);
    }



    @Operation(summary = "Find products by product name")
    @GetMapping("/productName/{productName}")
    public ResponseEntity<List<Product>> findByProductName(@PathVariable String productName) {
        return new ResponseEntity<List<Product>>(productService.findByProductName(productName), HttpStatus.OK);
    }

    @Operation(summary = "Update an existing product")
    @PutMapping("/{pid}")
    public ResponseEntity<Product> updateProduct(@PathVariable int pid, @RequestBody Product product)
            throws ProductIdNotFoundException {
        return new ResponseEntity<Product>(productService.updateProduct(pid, product), HttpStatus.OK);
    }

    @Operation(summary = "Delete a product by ID")
    @DeleteMapping("/{pid}")
    public ResponseEntity<Void> deleteProduct(@PathVariable int pid) throws ProductIdNotFoundException {
        productService.deleteProduct(pid);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
    
}
